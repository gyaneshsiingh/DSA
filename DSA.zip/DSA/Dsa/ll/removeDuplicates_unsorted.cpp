#include <bits/stdc++.h> 
Node *removeDuplicates(Node *head)
{
    Node* curr = head;
    Node* prev = NULL;
    unordered_set<int>st;
    while (curr != NULL) {
        if(st.find(curr->data) != st.end()){
            Node* dup = curr;
            prev->next = curr -> next;
            delete dup;
        }
        else {
            st.insert(curr->data);
            prev = curr;
        }
        curr = prev -> next;
    }
    return head;
}