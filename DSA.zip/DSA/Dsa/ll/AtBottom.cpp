#include <bits/stdc++.h> 
void AtBottom(stack<int>&st,int x){
    if(st.empty()){
        st.push(x);
        return;
    }
    int num = st.top();
    st.pop();

    AtBottom(st,x);
    st.push(num);
    return;

}
stack<int> pushAtBottom(stack<int> &myStack, int x) {
     AtBottom(myStack, x); 
     return myStack;
}

