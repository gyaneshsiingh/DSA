#timelimitexceed

class Solution {
public:
    int coinChange(vector<int>& coins, int amount) {
        int n = coins.size();
        int count = 0;
        if(n <= 1 && coins[0] < amount){
            return -1;
        }
        while(amount > 0){
            int i = 1;
            if(amount > coins[n-i]){
                amount-=coins[n-i];
                count++;
            }
            i++;
        }
        return count;
    }
};


#optimalsolution