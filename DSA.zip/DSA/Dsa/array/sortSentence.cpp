class Solution {
public:
    string sortSentence(string s) {
        map<int,string> str;
        string temp,sortSentence = "";
        int i = 0;

        while(i < s.size()){
            temp = "";

            while(!isdigit(s[i])){
                
                temp += s[i];

                i++;
            }

            str.insert({s[i],temp});
            i += 2;
        }
    for(auto x:str){
        sortSentence += x.second + " ";
    }

    sortSentence.erase(sortSentence.size()-1);

    return sortSentence;
    }
};