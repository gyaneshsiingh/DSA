class Solution {
public:
    int peakIndexInMountainArray(vector<int>& arr) {
        int maxi = INT_MIN;
        int index;
        int duplicate = 0;
        for (int i = 0; i < arr.size(); i++) {
            maxi = max(maxi, arr[i]);
            if(maxi > duplicate) {
                duplicate = maxi;
                index = i;
            }
        }
        return index;
    }
};