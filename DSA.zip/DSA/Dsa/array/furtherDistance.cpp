class Solution {
public:
    int furthestDistanceFromOrigin(string moves) {
        unordered_map<char,int>mp;
        for (int i = 0; i < moves.size(); i++) {
            mp[moves[i]]++;
        }
        return(max(mp['L'],mp['R']) - min(mp['L'],mp['R']) + mp['_']);
    }
};