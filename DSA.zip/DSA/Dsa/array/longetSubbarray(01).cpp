class Solution {
public:
    int longestSubarray(vector<int>& nums) {
        int ones = 0;
        int zeroes = 0;
        int maxi = 0;
        for(int i = 0; i < nums.size(); i++){
            if(nums[i] == 1){
            ones++;
        }
        else {
            zeroes = ones;
            ones = 0;
        }
        maxi = max(maxi,ones+zeroes);
    }
     if(nums.size() == maxi){
         return maxi-1;
     }
     return maxi;
 }
};