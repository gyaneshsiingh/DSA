class Solution {
public:
    int numIdenticalPairs(vector<int>& nums) {
        int count = 0;
        for(int i = 0; i < nums.size(); i++){
            int m = nums[i];
            for(int j = i + 1; j < nums.size(); j++){
                if(m == nums[j]){
                    count++;
                }
            }
        }
        return count;
    }
};

class Solution {
public:
    int numIdenticalPairs(vector<int>& nums) {
        unordered_map<int,int>mp;
        for(int i = 0; i < nums.size(); i++){
            mp[nums[i]]++;
        }
        int good_pairs = 0;
        for(auto i:mp){
            int n = i.second;
            good_pairs+=((n)*(n-1))/2;
        }
        return good_pairs;
    }
};