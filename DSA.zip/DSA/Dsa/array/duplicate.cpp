class Solution {
public:
    vector<int> findDuplicates(vector<int>& nums) {
        vector<int>dupli;
        int n = nums.size();
        if(n <= 1){
            return  dupli;
        }
        sort(nums.begin(),nums.end());
        for(int i = 1; i < nums.size(); i++){
            if(nums[i-1] == nums[i]){
                dupli.push_back(nums[i]);
            }
        }
        return dupli;
    }
};