class Solution {
public:
    vector<int> smallerNumbersThanCurrent(vector<int>& nums) {
        vector<int>v(nums.size(),0);
        for(int i = 0; i < nums.size(); i++){
            for(auto x:nums){
                if(x < nums[i]){
                    v[i]++;
                }
            }
        }
        return v;
    }
};