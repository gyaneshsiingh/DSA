class Solution {
   
public:
 static bool cmp(pair<int,int>&a ,pair<int,int>&b){
        return (a.second == b.second) ? a.first > b.first : a.second < b.second;
    }
    vector<int> frequencySort(vector<int>& nums) {
        if(nums.size() ==1){
            return nums;
        }
        vector<pair<int,int>>val;

        unordered_map<int,int>mp;

        for(int i = 0; i < nums.size(); i++){
            mp[nums[i]]++;
        }

        for(auto x:mp){
            val.push_back(x);
        }

        sort(val.begin(),val.end(),cmp);

        vector<int>res;

        for(auto freq: val){
            for(int j = 0; j < freq.second; j++){
            res.push_back(freq.first);
            }
        }

        return res;
    }
};