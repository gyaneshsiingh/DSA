class Solution {
public:
    char repeatedCharacter(string s) {
        char ans;

        unordered_map<char,int>mp;

        for (auto x:s) {
            if(mp.find(x) != mp.end()) {
                ans = x;
                break;
            }
            mp[x]++;
        }
        return ans;
    }
};