class Solution {
public:
    void rotate(vector<int>& nums, int k) {
        int size = nums.size();
        int num = 0;
        while(k>0){
            num = nums[size-1];
        for(int i = size-1; i >= 1; i--){
            nums[i] = nums[i-1];
        }
        nums[0] = num;
k--;
        }  
        
    }
};


#optimizing solution 
class Solution {
public:
    void rotate(vector<int>& nums, int k) {
        int size = nums.size();
        if(size == 0 || k == 0){
            return;
        }
        vector<int>numscopy(size);
        for(int i = 0; i< size; i++){
            numscopy[i] = nums[i];
        }
        for(int i = 0; i< size; i++){
            nums[(i+k)%size] = numscopy[i];
        }
    }
};