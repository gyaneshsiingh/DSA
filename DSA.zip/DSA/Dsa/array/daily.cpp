class Solution {
public:
    vector<int> dailyTemperatures(vector<int>& temp) {
    vector<int>res(temp.size(),0);
    stack<int>st;
    st.push(temp[0]);
    int n = temp.size();
    for (int i = 0; i < n; i++) {
        int count = 1;
      for(int j = i+1; j < n ; j++) {
          if(temp[i] >= temp[j]){
              count++;
          }
          else {
              res[i] = count;
              break;
          }
      }
    }
    return res;
  }
};