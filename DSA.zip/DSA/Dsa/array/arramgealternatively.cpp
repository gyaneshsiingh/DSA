class Solution {
public:
    vector<int> rearrangeArray(vector<int>& nums) {
         vector<int>v;
        vector<int>v1;
        for(int i = 0; i < nums.size(); i++){
            if(nums[i] >= 0){
                v.push_back(nums[i]);
            }
            else{
                v1.push_back(nums[i]);
            }
        }
        int i = 0;
        int j = 0;
        while(i < v.size() && i < v1.size()){
            nums[j] = v[i];
            j++;
            nums[j] = v1[i];
            i++,j++;
        }
        while(i < v.size()){
            nums[j] = v[i];
            j++,i++;
        }
        while(i < v1.size()){
            nums[j] = v1[i];
            j++,i++;
        }
        return nums;
	}
};