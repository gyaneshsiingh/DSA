class Solution {
public:
    vector<int> finalPrices(vector<int>& prices) {
        int n = prices.size();
        for(int i = 0; i < n; i++){
            int num = prices[i];
            int j = i+1;
        while(j < n){
            if(prices[j] <= num){
                int sum = num - prices[j];
                prices[i] = sum;
                break;
            }
            else{
                j++;
            }
        }
    }
    return prices;
  }
};