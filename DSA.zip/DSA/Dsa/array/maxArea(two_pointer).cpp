class Solution {
public:
    int maxArea(vector<int>& height) {
        int curr = 0;
        int max_num = 0;
        int low = 0;
        int high = height.size() - 1;
        while(low < high){
            curr = min(height[low],height[high])*(high-low);
            max_num = max(max_num,curr);
            if(height[low] < height[high]){
                low++;
            }
            else {
                high--;
            }
        }
        return max_num;
    }
};