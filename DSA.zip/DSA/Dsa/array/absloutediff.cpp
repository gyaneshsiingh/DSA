class Solution {
public:
    int countKDifference(vector<int>& nums, int k) {
    int count = 0;
    map<int,int>mp;
    for (int i = 0; i < nums.size(); i++) {
         mp[nums[i]]++;
    }
    for (auto x:mp){
        if(mp.find(x.first+k) != mp.end()){
            count += (mp[x.first+k]*mp[x.first]);
        }
    }
     return count;
   } 
};

class Solution {
public:
    int countKDifference(vector<int>& nums, int k) {
     int count = 0;
     for (int i = 0; i < nums.size(); i++) {
         for (int j = i+1; j < nums.size(); j++) {
             if(abs(nums[i]-nums[j]) == k){
                 count++;
             }
         }
     }
     return count;
   } 
};