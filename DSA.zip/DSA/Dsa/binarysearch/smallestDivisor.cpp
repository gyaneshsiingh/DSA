class Solution {
    int FindDiv(vector<int>&res,int div){
        int n = res.size();
        int num = 0;
        for(int i = 0; i < res.size(); i++){
            num+=ceil((double)res[i]/(double)div);
        }
        return num;
    }
public:

    int smallestDivisor(vector<int>& nums, int threshold) {
        int low = 1;
        int high = *max_element(nums.begin(),nums.end());
        int mid;
        while(low <= high){
            mid = (low + high)/2;
            if(FindDiv(nums,mid) <= threshold){
                high = mid - 1;
            }
            else{
                low = mid + 1;
            }
        }
        return low;
    }
};