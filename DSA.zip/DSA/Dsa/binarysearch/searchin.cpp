class Solution {
public:
    bool searchMatrix(vector<vector<int>>& matrix, int target) {
        int m = matrix.size();
        int n = matrix[0].size();
        if(n == 0 || m == 0){
            return false; 
        }
        int start = 0;
        int end = m * n- 1;
        while(start <= end){
            int mid =(start+end) / 2;
            int e = matrix[mid/n][mid%n];
            if(target < e){
                end = mid - 1;
            }
            else if(target > e){
                start = mid + 1;
            }
            else{
return true;
            }
        }
return false;
    }
};