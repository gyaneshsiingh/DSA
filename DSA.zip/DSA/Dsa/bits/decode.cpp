class Solution {
public:
    vector<int> decode(vector<int>& encoded, int first) {
       int ele = first;
       vector<int>res;
       res.push_back(first);
       for(int i = 0; i < encoded.size(); i++){
            ele^=encoded[i];
            res.push_back(ele);
        }
        return res;
    }
};