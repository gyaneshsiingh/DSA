#include<bits/stdc++.h>
#include <map>
using namespace std;
int findUnique(int *arr, int size)
{
    /*int ans = 0;
    map<int,int>mp;
    for(int i = 0; i < size; i++){
        mp[arr[i]]++;
    }
    for(auto x:mp){
        if(x.second == 1){
            return x.first;
        }
    }
    return -1;*/
    int ans = 0;
    for (int i = 0; i < size; i++){
        ans ^= arr[i];
    }
    return ans;
}