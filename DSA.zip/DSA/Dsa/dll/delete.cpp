

#include <iostream>
using namespace std;
class Node{
    public:
    int data;
    Node* prev;
    Node* next;
    Node(int val)
{
     data = val;
     next = NULL;
     prev = NULL;
}
};
void insertattails(Node* &head,int val){
    Node* n = new Node(val);
    if(head == NULL){
        head = n;
        return;
    }
    Node* temp = head;
    while(temp->next!= NULL){
        temp=temp->next;
    }
    temp->next = n;
    n->prev = temp;
}
Node* deletenum(Node* head){
    Node* temp = head;
    while(temp->next!=NULL){
        temp=temp->next;
    }
    Node* curr =temp;
    curr->prev->next=NULL;
    delete curr;
    return head;
}

void display(Node* head){
    Node* temp = head;
    while(temp!=NULL){
        cout << temp->data << endl;
        temp=temp->next;
    }
}
int main(){
    Node* head = NULL;
    insertattails(head,2);
    insertattails(head,333);
    insertattails(head,4);
   
     deletenum(head);
     display(head);
}
