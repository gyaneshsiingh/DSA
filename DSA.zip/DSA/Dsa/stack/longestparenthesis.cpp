class Solution {
public:
    int longestValidParentheses(string s) {
        int count = 0;
        stack<int>st;
        if(s.size() == 0) {
            return 0;
        }
        for (int i = 0; i < s.size(); i++) {
            char c = s[i];
            if(c == '(') {
                st.push(i);
            }
            else {
                if(!st.empty()){
             if(s[st.top()] == '(' ){
                    st.pop();
                }
                else {
                    st.push(i);
                }
            }
            else {
                st.push(i);
            }
        }
        }
        int longest = 0;
        
        if(st.empty()) {
        longest = s.size();
        }
        else {
            int a = s.size(),b = 0;
            while(!st.empty()) {
                b = st.top();
                st.pop();
                longest = max(longest,a-b-1);
                a = b;
            }
            longest = max(longest,a);
        }
        return longest;
    }
};