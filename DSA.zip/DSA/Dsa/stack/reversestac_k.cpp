#include <bits/stdc++.h>
void bottom(stack<int>&st,int x){
    if(st.empty()) {
        st.push(x);
        return;
    }
    int num = st.top();
    st.pop();
    
    bottom(st,x);
    st.push(num);
}
void reverseStack(stack<int> &stack) {
    if(stack.empty()) {
        return;
    }
    int x  = stack.top();
    stack.pop(); 
    reverseStack(stack);
    bottom(stack,x);
}