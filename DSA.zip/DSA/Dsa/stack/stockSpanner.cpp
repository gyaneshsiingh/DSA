class StockSpanner {
public:
    stack<pair<int,int>>st;
    int next(int price) {
        int ans = 1;
        while (!st.empty() && st.top().first <= price) {
            ans += st.top().second;
            st.pop();
        } 
        st.push({price,ans});
        return ans;
    }
};

/**
 * Your StockSpanner object will be instantiated and called as such:
 * StockSpanner* obj = new StockSpanner();
 * int param_1 = obj->next(price);
 */
 #include<bits/stdc++.h>
stack<pair<int,int>>st;
int next(int prices) {
    
   int ans = 1;
       while(!st.empty()  && st.top().first < prices){
           ans += st.top().second;
           st.pop();
       }
       st.push({prices,ans});
       return ans;

}
vector<int> findStockSpans(vector<int>& prices) {
   vector<int>res;
   for (int x:prices){
       int r = next(x);
       res.push_back(r);
   }
   return res;
}
