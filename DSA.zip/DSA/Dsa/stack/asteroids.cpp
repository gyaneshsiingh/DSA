class Solution {
public:
    vector<int> asteroidCollision(vector<int>& ast) {
        vector<int>res;
        stack<int>st;
        int n = ast.size();
        for(int i = 0; i < n; i++){
            if(ast[i] > 0 || st.empty()){
                st.push(ast[i]);
            }
            else{
                while(!st.empty() and st.top() > 0 and st.top() < abs(ast[i])) {
                    st.pop();
                }
                if(!st.empty() && st.top() == abs(ast[i])){
                    st.pop();
                }
                else{
                if(st.empty() || st.top() < 0){
                        st.push(ast[i]);
                    }
                }
            }
        }
       while(!st.empty()){
           res.push_back(st.top());
           st.pop();
       }
       reverse(res.begin(),res.end());
        return res;
    }
};