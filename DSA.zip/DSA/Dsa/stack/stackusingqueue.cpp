class MyStack {
public:
    queue<int>MyStack;
    
    void push(int x) {
        MyStack.push(x);
        int s = MyStack.size();
        for(int i = 1; i < s; i++){
            MyStack.push(MyStack.front());
            MyStack.pop();
            
        }
        
    }
    
    int pop() {
        int n = MyStack.front();
        MyStack.pop();
        return n;
        
    }
    
    int top() {
        return MyStack.front();
        
    }
    
    bool empty() {
        if(MyStack.empty()){
            return true;
        }
        return false;
    }
};

/**
 * Your MyStack object will be instantiated and called as such:
 * MyStack* obj = new MyStack();
 * obj->push(x);
 * int param_2 = obj->pop();
 * int param_3 = obj->top();
 * bool param_4 = obj->empty();
 */