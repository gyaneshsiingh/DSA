#include <bits/stdc++.h> 
void remove(stack<int>&st,int count,int N){
   if(count == N/2){
      st.pop();
      return;
   }
   int num = st.top();
   st.pop();
   
   remove(st,count+1,N);
   
   st.push(num);
}
void deleteMiddle(stack<int>&inputStack, int N){
   int count = 0;
   remove(inputStack,count,N);
}