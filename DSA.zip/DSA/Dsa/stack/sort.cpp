#include <bits/stdc++.h> 
void sort(stack<int>&st,int x){
	if(st.empty() || st.top() < x){
		st.push(x);
		return;
	}
	int num = st.top();
	st.pop();
	sort(st,x);
	st.push(num);

}
stack<int> sortStack(stack<int> &s)
{
	if (s.empty()) {
		return s;
	}
	int x = s.top();
	s.pop();
	sortStack(s);
	sort(s,x);
	return s;
}   