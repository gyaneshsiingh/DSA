#include <bits/stdc++.h>
void immediateSmaller(vector<int>& a)
{
	int n = a.size();
	stack<int>st;
	vector<int>res;
	st.push(a[0]);
	for(int i = 1; i < n; i++){
		int ele = a[i];
		if(st.top() > ele){
			a[i-1] = ele;
			st.pop();
		}
		else{
			a[i-1] = -1;
			st.pop();
		}
		st.push(ele);
	}
	a[n-1] = -1;

}
