#include<bits/stdc++.h>
using namespace std;
int main() {
    vector<char>res;
    int n = 5;
    stack<char>st;
    for (int i = 0; i < n; i++) {
        char c;
        cin >> c;
        res.push_back(c);
    }
    for (int i = 0; i < n; i++){
        st.push(res[i]);
    }
    vector<char>ans;
    while(!st.empty()) {
        char ch = st.top();
        ans.push_back(ch);
        st.pop();
    }
    for(int i = 0; i < ans.size(); i++ ){
        cout << ans[i] << " ";
    }
}