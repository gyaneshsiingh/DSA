class Solution {
public:
    int largestRectangleArea(vector<int>& heights) {
        
        int maxi = 0;
        for (int i = 0; i < heights.size(); i++) {
            int mini = INT_MAX;
            for (int j = i; j < heights.size(); j++) {
                mini = min(mini,heights[j]);
                maxi = max(maxi,mini*(j-i+1));
            }
        }
        return maxi;
    }
};
#include<bits/stdc++.h>
using namespace std;
 int largestRectangle(vector < int > & heights) {
   int n = heights.size();
  int maxi = 0;
  stack<int>st;
  int leftarr[n],rightarr[n];
  for (int i = 0; i < n; i++) {
    while (!st.empty() && heights[st.top()] >= heights[i]) {
      st.pop();
    }
    if (st.empty()) {
      leftarr[i] = 0;
    }
    else {
      leftarr[i] = st.top() + 1;
    }
    st.push(i);
  }
  while (!st.empty()) {
    st.pop();
  }
  for (int i = n - 1; i >= 0; i--) {
    while (!st.empty() && heights[st.top()] >= heights[i]) {
      st.pop();
    }
    if(st.empty()) {
      rightarr[i] = n - 1;
    }
    else {
      rightarr[i] = st.top() - 1;
    }
    st.push(i);
  }
  for (int i = 0; i < n; i++) {
    maxi = max(maxi, heights[i] * (rightarr[i] - leftarr[i] + 1));
  }
  return maxi;
 }