class Solution {
public:
    vector<vector<int>> combine(int n, int k) {
        vector<vector<int>>res;
        vector<int>ans;
        subset(1,res,ans,n,k);
        return res;
    }
    void subset(int i ,vector<vector<int>>&res,vector<int>&ans,int n,int k){
    if(ans.size() == k){
        res.push_back(ans);
        return;
    }
    for(int j = i; j <= n; j++){
        ans.push_back(j);
        subset(j+1,res,ans,n,k);
        ans.pop_back();
    }
}
};