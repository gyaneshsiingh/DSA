#include<bits/stdc++.h>
bool subset(int k,int n,vector<int>&a,int sum,int start) {
  if (sum == k) {
    return true;
  }
  if(sum > k ) return false;

  if(start >= n) return false;
    if(subset(k,n,a,sum+a[start],start+1)) return true;
    if(subset(k,n,a,sum,start+1)) return true;

}
bool isSubsetPresent(int n, int k, vector<int> &a)
{
   return subset(k,n,a,0,0);
}