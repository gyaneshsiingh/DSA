#include<bits/stdc++.h>

vector<string>res;
void f(string s,int n) {
    if(n == 0) {
        return;
    }
    for (int i = 0; i < n; i++) {
        if(i != 0 && s[i] == s[i-1]) continue;
        res.push_back(s.substr(i,n));
    }
    s.pop_back();
    f(s,n-1);
}

string moreSubsequence(int n, int m, string a, string b)
{
    f(a,n);
    int n1 = res.size();
    res.clear();
    f(b,m);
    int n2 = res.size();
    return n1 >= n2 ? a:b;
}