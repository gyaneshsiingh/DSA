class Solution {
public:
    void subset(string digits,vector<string>&output,vector<string>&alpha,string& temp,int index){
        if(index == digits.size()){
            output.push_back(temp);
            return;
        }
        string value = alpha[digits[index]- '0'];
        for(int i = 0; i < value.size(); i++){
            temp.push_back(value[i]);
            subset(digits,output,alpha,temp,index+1);
            temp.pop_back();
        }
    }
    vector<string> letterCombinations(string digits) {
        if(digits.empty()){
            return {};
        }
        vector<string>alpha = {"","","abc","def","ghi","jkl","mno","pqrs","tuv","wxyz"};
        vector<string>output;
        string temp;
        subset(digits,output,alpha,temp,0);
        return output; 
    }
};  