class Solution {
public:
     void subset(vector<int>& arr,int start,int target,vector<int>& ans,       vector<vector<int>>& res){
         if(target < 0) return;
         if(target == 0) res.push_back(ans);

         for(int i = start; i < arr.size(); i++){
             ans.push_back(arr[i]);
             subset(arr,i,target-arr[i],ans,res);
             ans.pop_back();
         }
    }
    vector<vector<int>> combinationSum(vector<int>& candidates, int target) {
        vector<int>ans;
        vector<vector<int>>res;
        subset(candidates,0,target,ans,res);
        return res;
    }
};