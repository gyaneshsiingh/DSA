#include <bits/stdc++.h>

void subset(vector<string>&ans,string temp,int start,int N){
    if(temp.size() == N) {
        ans.push_back(temp);
        return;
    }
      subset(ans, temp + "0", start + 1, N);
      if(temp == "" || temp.back() == '0')
      subset(ans,temp + "1" ,start+ 1, N);
}

vector<string> generateString(int N) {
    vector<string>ans;
    string temp;
    subset(ans,temp,0,N);
    return ans;
}