class Solution {
public:
    vector<vector<int>> subsets(vector<int>& nums) {
        vector<vector<int>>res = {{}};
        for(int num:nums){
            int n = res.size();
            for(int i = 0; i < n; i++){
               res.push_back(res[i]);
               res.back().push_back(num);
            }
        }
        return res;
    }
};

// above code is iterative approach 

class Solution {
public:
    vector<vector<int>> subsets(vector<int>& nums) {
        vector<vector<int>>res;
        vector<int>ans;
        subsets(0,nums,ans,res);
        return res;
    }
private:
    void subsets(int i,vector<int>&nums,vector<int>&ans,vector<vector<int>>&res){
        res.push_back(ans);
    for(int j = i; j < nums.size(); j++){
        ans.push_back(nums[j]);
        subsets(j+1,nums,ans,res);
        ans.pop_back();
    }
  }
};