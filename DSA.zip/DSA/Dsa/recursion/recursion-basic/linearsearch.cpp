#include <iostream>
using namespace std;
bool linearSearch(int arr[],int n,int k){
    if(n == 0){
        return false;
    }
    if(arr[0] == k){
        return true;
    }
    int remain = linearSearch(arr+1,n-1,k);
    return remain;
}
int main(){
    int arr[5] = {1,2,3,4,5};
    int n = 5;
    int k = 7;
    int ans = linearSearch(arr,n,k);
    if(ans){
        cout <<"found"<< endl;
    }
    else{
        cout << "Not Found" << endl;
    }
    
}