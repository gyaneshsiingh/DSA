#include <iostream>
using namespace std;
bool binarySearch(int arr[],int n,int s,int k){
    if(n == 0){
        return false;
    }
    int mid = (s+n)/2;
    if(arr[mid] == k){
        return true;
    }
    if(arr[mid] < k){
        return binarySearch(arr,mid+1,s,k);
    }
   else{
        return binarySearch(arr,mid-1,s,k);
    }
}
int main(){
    int arr[5] = {10,12,14,16,18};
    int n = 5;
    int k = 1;
    int s = 0;
    int ans = binarySearch(arr,n,s,k);
    if(ans){
        cout <<"Element Found using binary recursion" << endl;
    }
    else{
        cout << "Element Not Found" << endl;
    }
}