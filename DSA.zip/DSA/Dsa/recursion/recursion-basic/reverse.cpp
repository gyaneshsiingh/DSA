#include <iostream>
using namespace std;
void reverse(int arr[],int low,int high){
    if(low >= high){
        return;
    }
    else{
        swap(arr[low],arr[high]);
        reverse(arr,low+1,high-1);
    }
}
int main(){
    int arr[5] = {1,2,3,4,5};
    int n = 5;
    int low = 0;
    int high = n-1;
    reverse(arr,low,high);
    for(int i = 0; i < n; i++){
        cout << arr[i] << " "
    }
}