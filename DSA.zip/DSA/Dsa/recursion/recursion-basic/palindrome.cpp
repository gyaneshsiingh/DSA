#include <bits/stdc++.h>
using namespace std;
bool check(string &str,int low,int high){
    if(low >= high)
        return true;
    else if(str[low] != str[high]){
        return false;
    }
   return  check(str,low+1,high-1);
}
int main(){
    string str = "naan";
    int low = 0;
    int high = str.size() -1;
    cout << check(str,low,high);
    
}

#include <bits/stdc++.h>
using namespace std;
bool check(string &str,int low){
    if(low >= str.size()/2){
        return true;
    }
   if(str[low] != str[str.size() - low - 1]){
       return false;
   }
   return  check(str,low+1);
}
int main(){
    string str = "naan";
    int low = 0;
    cout << check(str,low);
    
}