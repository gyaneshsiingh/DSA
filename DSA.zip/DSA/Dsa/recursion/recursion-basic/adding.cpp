#include <iostream>
using namespace std;
int isSum(int *arr,int n){
    int sum = 0;
    cout << sum << endl;
    if(n == 0){
        return 0;
    }
    if(n==1){
        return arr[0];
    }
    else{
    int remain = isSum(arr+1,n-1);
    sum = arr[0] + remain;
    return sum;
    }
}
int main(){
    
    int arr[5] = {1,3,4,5,6};
    int n = 5;
    int sum = isSum(arr,n);
    cout << sum << endl;
    
}