int uniqueBinaryTree(int a, int b){
    if((a != b) && (a == 2 || b == 2)) return 1;
    return 0;
}