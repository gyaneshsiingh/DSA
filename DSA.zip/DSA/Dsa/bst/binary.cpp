#include<bits/stdc++.h>
using namespace std;
class node{
    public:
    int val;
    node* left;
    node* right;
    node(int data){
    val = data;
    left = NULL;
    right = NULL;
    }
};
void preorder(node* &head) {
    if(head == NULL) {
        return;
    }
    cout << head->val << " ";
    preorder(head->left);
    preorder(head->right);
}
void inorder(node* &head) {
    if(head == NULL) {
        return;
    }

    inorder(head->left);
    cout << head->val << " ";
    inorder(head->right);
}
void postorder(node* &head) {
    if(head == NULL) {
        return;
    }

    postorder(head->left);
    postorder(head->right);
    cout << head->val << " ";
}


int main() {
    node* head = new node(1);
    head->left = new node(2);
    head->right = new node(3);
    head->left->left = new node(4);
    head->left->right = new node(5);
    head->right->left = new node(6);
    head->right->right = new node(7);
    preorder(head);
}