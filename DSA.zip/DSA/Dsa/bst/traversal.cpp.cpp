#include<bits/stdc++.h>
using namespace std;
void preorder(TreeNode* root,vector<int>&pre){
    if(root == NULL ) return;

    pre.push_back(root -> data);
     preorder(root->left,pre);
    preorder(root->right,pre);

}
void postorder(TreeNode* root,vector<int>&post){
    if(root == NULL ) return;

     postorder(root->left,post);
     postorder(root->right,post);
    post.push_back(root -> data);

}
void inorder(TreeNode* root,vector<int>&in_){

    if(root == NULL ) return;

     inorder(root->left,in_);
    in_.push_back(root->data);
     inorder(root->right,in_);

}
vector<vector<int>> getTreeTraversal(TreeNode *root){
    vector<vector<int>>ans(3);
    preorder(root,ans[1]);
    postorder(root,ans[2]);
    inorder(root,ans[0]);
    return ans;
}