/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution {
public:
    int diameterOfBinaryTree(TreeNode* root) {
        if(root == NULL) {
            return 0;
        }
        int left = diameter(root -> left);
        int right = diameter(root -> right);

        int maxi = max(left,right);
        return maxi;
        
    }
    int diameter (TreeNode* root) {
        if(root == NULL) {
            return 0;
        }

        int left = diameter(root -> left);
        int right = diameter(root -> right);
         int dia = diameter(root -> left) + diameter(root -> right) + 1;

        int maxi = max(left,max(right,dia));

        return maxi;
    }
};


/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution {
private:
    int diameter;
public:
    int height(TreeNode* root) {
        if(root == NULL) {
            return 0;
        }
        int left = height(root->left);
        int right = height(root->right);

        diameter = max(diameter,left+right);

        return max(left,right)+1;
    }
    int diameterOfBinaryTree(TreeNode* root) {
        diameter = 0;
        height(root);
        return diameter;
    }
    
};