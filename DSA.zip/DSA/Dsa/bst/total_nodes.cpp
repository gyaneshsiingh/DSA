#include <bits/stdc++.h> 
using namespace std;
int left(BinaryTreeNode<int> *root) {
    int h = 0;
    while(root) {
        h++;
        root = root -> left;
    }
    return h;
}
int right(BinaryTreeNode<int >*root) {
    int h = 0;
    while(root) {
        h++;
        root = root -> right;
    }
    return h;
}

int countNodes(BinaryTreeNode<int> *root) {
    if(root == NULL) {
        return 0;
    }
  int lh = left(root);
  int rh = right(root);
  if(lh == rh) {
      return pow(2,lh)-1;
  }
  return countNodes(root -> right) + countNodes(root -> left) +1;
}