#include<bits/stdc++.h>
bool symmetric(TreeNode<int>*root1,TreeNode<int>*root2) {
    if(root1 == NULL || root2 == NULL) return root1 == root2;
    return (root1->data == root2->data) && symmetric(root1 -> left,root2 -> right) && symmetric(root1 -> right,root2 -> left);
}
bool isSymmetric(TreeNode<int> *root)
{
    if (root == NULL) {
      return true;
    }
    return symmetric(root->left,root->right);
}