#include <bits/stdc++.h>
using namespace std;
void preorder (TreeNode<int>* root,vector<int>&res) {
if(root == NULL) {
        return;
    }

    res.push_back(root->data); 
    preorder(root->left,res);
    preorder(root->right,res);

}
vector<int> preOrder(TreeNode<int> * root){
    // Write your code here.
    vector<int>res;
    preorder(root,res);
    return res;
}
