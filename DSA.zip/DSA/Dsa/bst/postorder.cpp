#include<bits/stdc++.h>
using namespace std;
void postorder(TreeNode* &root,vector<int>&res) {
    if(root == NULL) {
        return;
    }
    postorder(root -> left,res);
    postorder(root -> right,res);
    res.push_back(root->data);
}
vector<int> postorderTraversal(TreeNode *root)
{
    vector<int>res;
   postorder(root,res);
    return res;
}