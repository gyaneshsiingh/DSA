class Solution {
public:
    bool areOccurrencesEqual(string s) {
        unordered_map<char,int>mp;
        int maxi = -1;
        for(int i = 0; i < s.size(); i++){
            mp[s[i]]++;
            maxi = max(maxi,mp[s[i]]);
        }
        for(auto x:mp){
            if(x.second != maxi){
                return false;
            }
        }
        return true;
    }
};