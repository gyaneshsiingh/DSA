class Solution {
public:
    int myAtoi(string s) {
        double res = 0;
        long long val = 0;
        long long  sign = 1;
        int index = 0;
        while(s[index] == ' '){
            index++;
        }
        bool positive = s[index] == '+';
        bool negative = s[index] == '-'; 
        positive == true ? index++ : index;
        negative == true ? index++ : index;
        while(index < s.size() &&  s[index] >= '0' && s[index] <= '9'){
           res = res*10 + (s[index]-'0');  
            index++;
        }
        res = negative ? -res : res;
        res = (res > INT_MAX) ? INT_MAX : res;
        res = (res < INT_MIN) ? INT_MIN : res;


        return int(res);
    }
};