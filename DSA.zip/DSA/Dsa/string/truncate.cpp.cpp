class Solution {
public:
    string truncateSentence(string s, int k) {
        string str = "";
        int size = s.size();
        int i(0);
        int j = 0;
            while(i < size){
                if(s[i] == ' '){
                    j++;
                }
                if(j == k){
                    break;
                }
                str+=s[i];
                i++;
            }
        return str;
    }
};