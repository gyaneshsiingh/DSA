class Solution {
public:
    void reverseString(vector<char>& s) {
        int low = 0;
        int high = s.size()-1;
        int mid = 0;
        while(low <= high){
            swap(s[low++],s[high--]);
        }

    }
};