class Solution {
public:
    bool arrayStringsAreEqual(vector<string>& word1, vector<string>& word2) {
        string str1 = "";
        string str2 = "";
        for(int i = 0; i < word1.size(); i++){
            str1+=word1[i];
        }
        for(int i = 0; i < word2.size(); i++){
            str2+=word2[i];
        }
        int i(0),j(0);
        if(str1.size() != str2.size()){
            return false;
        }
        while(i < str1.size() && j <  str2.size()){
            if(str1[i]!=str2[j]){
                return false;
            }
            i++;
            j++;
        }
        return true;
    }
};