class Solution {
public:
    string interpret(string command) {
        string str = "";
        int i = 0;
        while(i < command.size()){
            if(command[i] == 'G' || command[i] == 'a' || command[i] == 'l'){
                str+=command[i];
                i++;
            }
           else  if(command[i] == '(' && command[i+1] == ')'){
                char c = 'o';
                str+=c;
                i+=2;
            }
            else{
                i++;
            }
        }
        return str;
    }
};