class Solution {
public:
    string defangIPaddr(string address) {
        int size = address.size();
        string ans = "";
        for(int i  = 0; i < size; i++){
            if(address[i] == '.'){
                ans = ans + "[.]";
            }
            else{
                ans = ans + address[i];
            }
        }
        return ans;
    }
};