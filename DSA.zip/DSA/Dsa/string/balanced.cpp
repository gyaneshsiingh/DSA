class Solution {
public:
    int balancedStringSplit(string s) {
        int count = 0;
        int res = 0;
        int i = 0;
        while(i < s.size()){
            if(s[i] == 'R'){
                count++;
            }
            else{
                count--;
            }
            if(count == 0){
                res++;
            }
         i++;
        }
        return res;
    }
};