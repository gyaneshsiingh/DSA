class Solution {
public:
    string removeTrailingZeros(string num) {

        int n = num.size()-1;

        while(n != 0){
            if(num[n] == '0'){
                num.pop_back();
            }
            else{
                break;
            }
            n--;
        }
        return num;
    }
};