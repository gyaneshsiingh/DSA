class Solution {
public:
    string toLowerCase(string s) {
        string ans = "";
       int i = 0;
       while(i < s.size()){
       if(s[i] >= 'a' && s[i] <= 'z'){
           ans+=s[i];
       }
       else if(s[i] >= 'A' && s[i] <= 'Z'){
           int res = s[i]+32;
           cout << res;
           char c = res;
           ans+=c;
       }
       else{
           ans+=s[i];
       }
       i++;
       }
       return ans;
    }
};