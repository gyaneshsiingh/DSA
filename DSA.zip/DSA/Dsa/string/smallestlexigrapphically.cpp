class Solution {
public:
    string makeSmallestPalindrome(string s) {
        int low = 0;
        int high = s.size() - 1;
        while(low <= high){
            if(s[low] == s[high]){
                low++;
                high--;
            }
            else{
                int a = s[low] - '0';
                int b = s[high] - '0';
                if(a > b){
                    s[low++] = s[high--];
                }
                else{
                    s[high--] = s[low++];
                }
            }
        }
        return s;
    }
};