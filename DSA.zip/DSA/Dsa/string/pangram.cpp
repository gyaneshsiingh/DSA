class Solution {
public:
    bool checkIfPangram(string s) {
        map<char,int>mp;
        int first = 0;
        for (int i = 0; i < s.size(); i++) {
            mp[s[i]]++;
        }
        for(auto x:mp) {
            if(x.first != 0) {
                first++;
            }
        }
        if(first != 26){
        return false;
        }
        return true;
    }
};