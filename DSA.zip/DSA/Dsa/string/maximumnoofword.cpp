class Solution {
public:
    int mostWordsFound(vector<string>& sentences) {
        int size = sentences.size();
        int maxx = 0;
        int count;
        for(int i = 0; i < size; i++){
             count = 1;
             int k = sentences[i].size();
            for(int j= 0; j < k; j++){
                 if(sentences[i][j] == ' '){
                     count++;
            }
        }
        maxx = max(count,maxx);
        }
    return maxx;
    }
};