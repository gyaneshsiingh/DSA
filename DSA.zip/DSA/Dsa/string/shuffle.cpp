class Solution {
public:
    string restoreString(string s, vector<int>& indices) {
        vector<char>res(indices.size(),'0');
        string str = "";
        for(int i = 0; i < indices.size(); i++){
            res[indices[i]] = s[i];
        }
        for(int i = 0; i < res.size(); i++){
           str+=res[i];
        }

        return str;
    }
};
class Solution {
public:
    string restoreString(string s, vector<int>& ind) {
        string ans = s;
        for(int i=0;i<s.size();i++) {
            ans[ind[i]] = s[i];
        }
        return ans;
    }
};