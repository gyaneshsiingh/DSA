class Solution {
public:
    string replaceDigits(string s) {
        string ans = "";
        int i = 0;
       while(i < s.size()){
            if(s[i] >= 'a' && s[i] <= 'z'){
                ans+=s[i];
            }
            else{
                int c = s[i] - '0';
                int res = s[i-1] + c;
                char d = res;
                ans+=d;
            }
            i++;
       }
        return ans;
    }
};